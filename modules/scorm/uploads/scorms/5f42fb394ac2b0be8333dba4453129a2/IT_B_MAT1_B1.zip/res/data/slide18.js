(function(){var loadHandler=window['sl_{A2720DE4-45F5-4D44-8769-E714CEEF47E3}'];loadHandler&&loadHandler(17, '<div id="spr0_62585451"><div id="spr1_62585451" class="kern"><img id="img2_62585451" src="data/img3.png" width="1080px" height="810px" alt="" style="left:0px;top:0px;"/><div id="spr3_62585451"><img id="img0_62585451" src="data/img0.png" width="1081" height="811" alt="Plantillas Instituto Toks-01-03.png" style="left:0.176px;top:0.176px;"/></div></div><div id="spr2_62585451" class="kern"><div id="spr4_62585451" style="left:67px;top:163px;"><img id="img1_62585451" src="data/img10.png" width="880" height="493" alt="¿Qué es un valor absoluto? \
\
El valor absoluto de cualquier número real, siempre es positivo.\
\
Se representa con unas barras verticales.\
\
Ejemplos:\
\
 4 =4\
\
 −4 =4\
\
 0 =0"/></div><div id="spr5_62585451" style="left:33.353px;top:16.412px;"><div style="width:0px;"><span id="txt0_62585451" data-width="520.877930" style="left:10.8px;top:37.656px;">Operaciones con números reales</span></div></div></div></div>');})();
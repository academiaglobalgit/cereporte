(function(){var loadHandler=window['sl_{3045A5E3-9AA6-41A5-8699-E7E059B57238}'];loadHandler&&loadHandler(15, '<div id="spr0_62619074"><div id="spr1_62619074" class="kern"><img id="img4_62619074" src="data/img3.png" width="1080px" height="810px" alt="" style="left:0px;top:0px;"/><div id="spr3_62619074"><img id="img0_62619074" src="data/img0.png" width="1081" height="811" alt="Plantillas Instituto Toks-01-03.png" style="left:0.176px;top:0.176px;"/></div></div><div id="spr2_62619074" class="kern"><div id="spr4_62619074" style="left:138px;top:683px;"><img id="img1_62619074" src="data/img32.png" width="786" height="61" alt=""/></div><div id="spr5_62619074" style="left:479px;top:540px;"><img id="img2_62619074" src="data/img33.png" width="107" height="56" alt=""/></div><div id="spr6_62619074" style="left:44px;top:159px;"><img id="img3_62619074" src="data/img34.png" width="975" height="566" alt="La última expresión de la diapositiva anterior, puede ser resuelta utilizando los métodos estudiados en este bloque de aprendizaje:\
\
x + x + 1 = 71\
\
2x + 1 = 71\
\
2x = 71 - 1\
\
2x = 70\
\
x  =  70 2 \
\
x = 35\
	\
Por lo tanto, si x=35 y el otro número es y=x+1, entonces y = 35 + 1 = 36.\
\
De esta manera, los números que buscamos son 35 y 36."/></div><div id="spr7_62619074" style="left:23.824px;top:16.41px;"><div style="width:0px;"><span id="txt0_62619074" data-width="801.742676" style="left:10.8px;top:6.999px;">Situaciones que generan ecuaciones de primer grado</span></div><div style="width:0px;"><span id="txt1_62619074" data-width="248.585449" style="left:10.8px;top:44.799px;">con una variable</span></div></div></div></div>');})();